void tune(unsigned char,char);
void playsong2()
{
tune(4,-5);tune(3,1);tune(1,3);tune(4,5);tune(3,3);tune(1,4);tune(6,5);tune(2,6);tune(8,5);tune(3,6);
tune(1,5);tune(2,4);tune(2,3);tune(4,2);tune(4,-5);tune(4,-7);tune(2,2);tune(1,1);tune(1,-7);tune(4,1);
tune(4,0);tune(4,1);tune(4,1);tune(4,1);tune(2,1);tune(2,2);tune(6,3);tune(2,2);tune(8,1);tune(4,0);
tune(4,2);tune(4,2);tune(4,2);tune(2,-6);tune(2,1);tune(6,-7);tune(2,-6);tune(4,-5);tune(4,0);tune(4,1);
tune(2,1);tune(2,1);tune(4,1);tune(2,-3);tune(2,1);tune(6,-7);tune(2,1);tune(8,-6);tune(4,2);tune(3,2);
tune(1,1);tune(3,2);tune(1,2);tune(2,2);tune(2,3);tune(8,2);tune(8,2);tune(4,1);tune(4,1);tune(4,1);
tune(2,1);tune(2,2);tune(6,3);tune(2,2);tune(8,1);tune(4,0);tune(4,2);tune(4,2);tune(4,2);tune(2,-6);
tune(2,1);tune(6,-7);tune(2,-6);tune(4,-5);tune(4,0);tune(4,1);tune(2,1);tune(2,1);tune(4,1);tune(2,-3);
tune(2,1);tune(6,-7);tune(2,1);tune(8,-6);tune(4,2);tune(3,2);tune(1,1);tune(3,2);tune(1,2);tune(2,2);
tune(2,3);tune(8,5);tune(8,5);tune(2,3);tune(6,3);tune(2,2);tune(4,1);tune(4,0);tune(3,-7);tune(1,-7);
tune(1,-7);tune(3,-5);tune(8,-3);tune(6,-6);tune(2,-7);tune(4,1);tune(2,2);tune(2,3);tune(6,-7);tune(2,-6);
tune(8,-6);tune(3,2);tune(1,2);tune(2,2);tune(2,1);tune(8,2);tune(6,2);tune(2,-5);tune(4,1);tune(2,2);
tune(2,3);tune(6,2);tune(2,1);tune(8,2);tune(4,-5);tune(4,-5);tune(4,1);tune(4,3);tune(6,5);tune(2,4);
tune(2,3);tune(2,2);tune(4,3);tune(3,-5);tune(1,-5);tune(2,1);tune(2,3);tune(3,5);tune(1,4);tune(2,3);
tune(2,2);tune(8,3);tune(8,3);tune(4,-5);tune(4,-5);tune(4,1);tune(4,3);tune(6,5);tune(2,4);tune(2,3);
tune(2,2);tune(4,3);tune(3,-5);tune(1,-5);tune(2,1);tune(2,3);tune(3,5);tune(1,4);tune(2,3);tune(2,2);
tune(8,3);tune(8,3);tune(6,2);tune(2,1);tune(4,2);tune(4,3);tune(6,5);tune(2,5);tune(8,5);tune(12,1);
tune(4,0);tune(3,5);tune(1,5);tune(4,6);tune(4,5);tune(4,0);tune(6,5);tune(2,5);tune(8,6);tune(8,8);
tune(8,8);tune(8,8);tune(8,8);tune(4,8);
}

void playsong1()
{
tune(4,0);tune(2,-5);tune(6,1);tune(2,1);tune(3,1);tune(1,1);tune(2,-5);tune(1,-6);tune(1,-7);tune(4,1);
tune(4,1);tune(2,0);tune(2,3);tune(2,1);tune(1,2);tune(1,3);tune(3,5);tune(1,5);tune(4,5);tune(3,3);
tune(1,3);tune(3,1);tune(1,3);tune(3,5);tune(1,3);tune(4,2);tune(8,2);tune(4,6);tune(4,5);tune(4,2);
tune(4,3);tune(2,5);tune(4,3);tune(2,5);tune(2,3);tune(1,2);tune(1,3);tune(3,1);tune(1,3);tune(4,3);
tune(4,0);tune(3,-5);tune(1,-6);tune(2,1);tune(2,1);tune(3,3);tune(1,3);tune(3,5);tune(1,5);tune(2,2);
tune(1,2);tune(1,2);tune(3,-6);tune(1,-6);tune(6,2);tune(2,-5);tune(6,1);tune(2,1);tune(6,3);tune(2,3);
tune(8,5);tune(8,5);tune(3,1);tune(1,3);tune(3,5);tune(1,5);tune(4,6);tune(4,5);tune(3,3);tune(1,1);tune(2,5);
tune(1,5);tune(1,5);tune(2,3);tune(2,0);tune(2,1);tune(2,0);tune(4,-5);tune(4,1);tune(3,3);tune(1,1);
tune(2,5);tune(1,5);tune(1,5);tune(2,3);tune(2,0);tune(2,1);tune(2,0);tune(4,-5);tune(4,1);tune(4,-5);
tune(4,1);tune(4,-5);tune(4,1);tune(8,1);tune(8,1);
}

void playsong3()
{
tune(8,10);tune(8,9);tune(8,8);tune(8,7);tune(8,6);tune(8,5);tune(8,6);tune(8,7);tune(8,8);tune(8,7);
tune(8,6);tune(8,5);tune(8,4);tune(8,3);tune(8,4);tune(8,2);tune(2,8);tune(2,7);tune(2,8);tune(2,1);
tune(2,-7);tune(2,5);tune(2,2);tune(2,3);tune(2,1);tune(2,8);tune(2,7);tune(2,6);tune(2,7);tune(2,10);
tune(2,12);tune(2,12);tune(2,11);tune(2,10);tune(2,9);tune(2,11);tune(2,11);tune(2,10);tune(2,8);tune(2,7);
tune(2,6);tune(2,5);tune(2,4);tune(2,3);tune(2,2);tune(2,4);tune(2,3);tune(2,2);tune(2,1);tune(2,2);
tune(2,3);tune(2,4);tune(2,5);tune(2,2);tune(2,5);tune(2,4);tune(2,3);tune(2,6);tune(2,5);tune(2,4);
tune(2,5);tune(2,4);tune(2,3);tune(2,2);tune(2,1);tune(2,-6);tune(2,6);tune(2,7);tune(2,8);tune(2,7);
tune(2,6);tune(2,5);tune(2,4);tune(2,3);tune(2,2);tune(2,6);tune(2,5);tune(2,6);tune(2,5);tune(2,4);
tune(4,3);tune(4,10);tune(8,9);tune(8,8);tune(8,9);tune(4,8);tune(4,10);tune(4,9);tune(4,11);

tune(2,12);tune(1,10);tune(1,11);tune(2,12);tune(1,10);tune(1,11);tune(1,12);tune(1,5);tune(1,6);tune(1,7);
tune(1,8);tune(1,9);tune(1,10);tune(1,11);tune(2,10);tune(1,8);tune(1,9);tune(2,10);tune(1,3);tune(1,4);
tune(1,5);tune(1,6);tune(1,5);tune(1,4);tune(1,5);tune(1,3);tune(1,4);tune(1,5);tune(2,4);tune(1,6);
tune(1,5);tune(2,4);tune(1,3);tune(1,2);tune(1,3);tune(1,2);tune(1,1);tune(1,2);tune(1,3);tune(1,4);
tune(1,5);tune(1,6);tune(2,4);tune(1,6);tune(1,5);tune(2,6);tune(1,7);tune(1,8);tune(1,5);tune(1,6);
tune(1,7);tune(1,8);tune(1,9);tune(1,10);tune(1,11);tune(1,12);tune(2,10);tune(1,8);tune(1,9);tune(2,10);
tune(1,9);tune(1,8);tune(1,9);tune(1,7);tune(1,8);tune(1,9);tune(1,10);tune(1,9);tune(1,8);tune(1,7);
tune(2,8);tune(1,6);tune(1,7);tune(2,8);tune(1,1);tune(1,2);tune(1,3);tune(1,4);tune(1,3);tune(1,2);
tune(1,3);tune(1,8);tune(1,7);tune(1,8);tune(2,6);tune(1,8);tune(1,7);tune(2,6);tune(1,5);tune(1,4);
tune(1,5);tune(1,4);tune(1,3);tune(1,4);tune(1,5);tune(1,6);tune(1,7);tune(1,8);tune(2,6);tune(1,8);
tune(1,7);tune(2,8);tune(1,7);tune(1,6);tune(1,7);tune(1,8);tune(1,9);tune(1,8);tune(1,7);tune(1,8);
tune(1,6);tune(1,7);tune(4,8);


}

void playself()
{
	char j=0;
	while(sound[j]!=99)
	{
		tune(rap[j],sound[j]);
		j++;
	}
}
